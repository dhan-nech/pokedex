import PokemonPage from "@/components/organisms/pokemon-details";

export default function PokemonDetailPage() {
  return <PokemonPage />;
}