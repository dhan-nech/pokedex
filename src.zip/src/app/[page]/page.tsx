// app/[page]/page.tsx
'use client'

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Header from "@/components/molecules/header";
import TypeDD from "@/components/molecules/type-dd";
import GenderDD from "@/components/molecules/gender-dd";
import SearchBox from "@/components/molecules/search";
import { FaBars } from "react-icons/fa";
import PokemonGrid from "@/components/organisms/pokemon-grid";

export default function Home({ params }: { params: { page: string } }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const currentPage = parseInt(params.page) || 1;

  useEffect(() => {
    const newUrl = searchQuery 
      ? `/${currentPage}?search=${encodeURIComponent(searchQuery)}` 
      : `/${currentPage}`;
    router.push(newUrl, { scroll: false });
  }, [searchQuery, currentPage, router]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    router.push(`/1?search=${encodeURIComponent(query)}`, { scroll: false });
  };

  return (
    <main className="flex min-h-screen flex-col bg-mainbg">
      <Header />
      <div className="flex justify-between items-center p-4">
        <SearchBox onSearch={handleSearch} searchQuery={searchQuery} />
        <div className="md:hidden">
          <FaBars size={36}/>
        </div>
        <div className="hidden md:flex space-x-4">
          <TypeDD />
          <GenderDD />
        </div>
      </div>
      <PokemonGrid searchQuery={searchQuery} currentPage={currentPage} />
    </main>
  );
}