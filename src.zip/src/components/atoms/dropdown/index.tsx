'use client'

import React, { useState, useRef, useEffect } from 'react';

const Dropdown = ({ label = 'Select', options = [] }) => {
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const handleOptionChange = (e) => {
    const option = e.target.value;
    setSelectedOptions((prevOptions) => {
      if (e.target.checked) {
        return [...prevOptions, option];
      } else {
        return prevOptions.filter((opt) => opt !== option);
      }
    });
  };

  const getDisplayText = () => {
    if (selectedOptions.length === 0) {
      return label;
    } else if (selectedOptions.length === 1) {
      return selectedOptions[0];
    } else {
      return `${selectedOptions[0]} + ${selectedOptions.length - 1} more`;
    }
  };

  const toggleDropdown = () => {
    setIsOpen((prevIsOpen) => !prevIsOpen);
  };

  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);

  const handleOptionClick = (e) => {
    e.stopPropagation();
  };

  return (
    <div className='flex flex-col ml-10 mt-[-21px]' ref={dropdownRef}>
      <label className='text-maintext text-[10px] flex ml-2'>{label}</label>
      <div
        className='bg-searchbox w-[200px] p-2.5 mt-[1px] rounded-md cursor-pointer border'
        onClick={toggleDropdown}>
        <div className='flex items-center justify-between'>
          <span className='text-sm'>{getDisplayText()}</span>
          <svg
            xmlns='http://www.w3.org/2000/svg'
            className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`}
            viewBox='0 0 20 20'
            fill='currentColor'>
            <path
              fillRule='evenodd'
              d='M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z'
              clipRule='evenodd'
            />
          </svg>
        </div>
        {isOpen && (
          <div className='mt-2 bg-white rounded-md shadow-lg border absolute w-[200px] ml-[-10px]'>
            {options.map((option, index) => (
              <div key={option} className={`flex items-center ${index !== options.length - 1 ? 'border-b' : ''} p-2`} onClick={handleOptionClick}>
                <input
                  type='checkbox'
                  id={option.toLowerCase()}
                  value={option}
                  onChange={handleOptionChange}
                  checked={selectedOptions.includes(option)}
                  className='mr-2'
                />
                <label htmlFor={option.toLowerCase()} className='ml-2'>
                  {option}
                </label>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dropdown;