import Image from 'next/image';
import React from 'react';

interface CardProps {
  imageSrc: string;
  name: string;
  number: number;
  onClick: () => void; 
}

const PokeCard: React.FC<CardProps> = ({ imageSrc, name, number, onClick }) => {
  return (
    <div
      className="border border-dashed border-red-300 rounded-lg p-2 bg-blue-100 flex flex-col cursor-pointer h-full w-[164px]"
      onClick={onClick}
    >
      <div className="h-[150px] w-24 mx-auto mb-2 pt-5">
        <Image src={imageSrc} alt={name} className="mx-auto object-contain" height={100} width={96} />
      </div>
      <h2 className="text-lg font-bold mb-1 text-center capitalize">{name}</h2>
      <p className="text-md font-bold text-center">{number.toString().padStart(3, '0')}</p>
    </div>
  );
};

export default PokeCard;