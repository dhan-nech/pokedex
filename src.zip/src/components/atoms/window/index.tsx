const Window = () => {
    return <div>This is the window content</div>;
};

export default Window;
