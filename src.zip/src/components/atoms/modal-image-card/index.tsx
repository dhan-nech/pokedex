'use client';
import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
 
interface ModalCardProps {
 
  pokemonData: any;
}
 
const ModalImageCard: React.FC<ModalCardProps> = ({ pokemonData}) => {
  return (
    // <div>
    //   <div
    //     className="max-w-sm rounded overflow-hidden border-2 border-dashed border-gray-300 cursor-pointer"
    //   >
    //     <div className="flex flex-col px-6 py-4 justify-center items-center">
    //       <Image className="w-full" src={image}
    //       width={100} height={100}
    //       alt='pokemon'/>
    //     </div>
    //   </div>
     
    // </div>
    <div>
 
      <Link href={`/pokemon/${pokemonData?pokemonData.id:''}`}>
        <div
          className="max-w-[170px] md:w-[200px] sm:w-[200px] h-[250px] rounded overflow-hidden border-2 border-dashed border-gray-300 cursor-pointer"
 
        >
 
          <div className="flex h-full flex-col justify-center items-center">
            <div className='pt-5 h-3/4 '>
              <Image width={100} height={100} src={ pokemonData && pokemonData.image?pokemonData.image:""} alt='image' className='object-contain h-full ' />
            </div>
           
          </div>
        </div>
      </Link>
    </div>
  );
};
 
export default ModalImageCard;