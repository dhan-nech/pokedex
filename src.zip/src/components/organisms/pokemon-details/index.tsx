'use client'
import React, { useEffect, useState } from 'react';

import EvolutionChain from '@/components/atoms/evolution-chain';
import ModalControlButtons from '@/components/atoms/modal-control-buttons';
import CloseButton from '@/components/atoms/close-button';
import ModalImageCard from '@/components/atoms/modal-image-card';
    
import axios from 'axios';

import { usePathname } from 'next/navigation';

const PokemonPage = () => {
 
  // const [data, setData] = useState<any>();
  const [curId, setCurId] = useState<number>();
  const pathname = usePathname();
  console.log(pathname);
  const parts = pathname.split('/');
  const id = parts[2];
  const [structuredData, setStructuredData] = useState<any>();
  const [dataSpecies, setDataSpecies] = useState<any>();
  const [pokemonData, setPokemonData] = useState<any>();
 
 
 
  const fetchPokemonModal = async (url: string = `https://pokeapi.co/api/v2/pokemon/${id}/`) => {
    try {
      //dispatch(fetchPokemonStart());
      // console.log('inside try');
      // const response = await axios.get(url)
      await axios.get(url)
        .then(res => {

          setStructuredData(res.data);
          const formattedData = {
            image: res.data.sprites.other.dream_world.front_default,
            types: res.data.types,
            id: res.data.id
          }
          setPokemonData(formattedData);
          return res.data;
        })
        .catch(err =>{
          console.log(err);
         
        })
 
    }
    //   dispatch(fetchPokemonModalSuccess(response.data));
    catch (error) {
      //   dispatch(fetchPokemonFailure(error.message));
    }
  };
 
  const fetchPokemonSpecies = async(url:string=`https://pokeapi.co/api/v2/pokemon-species/${id}`)=>{
    try{
      await axios.get(url)
        .then(res => {
          setDataSpecies(res.data);
         
          return res.data;
        })
        .catch(err =>{
          console.log(err);
         
        })
    }
    catch(err){
 
    }
  }
  useEffect( () => {
    fetchPokemonModal();
    fetchPokemonSpecies();
    setCurId(Number(id));
   
  }, [curId])
 
  console.log('imagedata',pokemonData)
 
  var para = 'Text Here'
  const [showFullDescription, setShowFullDescription] = useState(false);
 
  const handleReadMore = () => {
    setShowFullDescription(true);
  };
 
  const handleReadLess = () => {
    setShowFullDescription(false);
  };
 
  return (
    <div className="fixed inset-0 z-50 flex overflow-y-auto justify-center bg-black bg-opacity-50">
      <div className="p-5 bg-mainbg h-fit rounded-lg max-w-4xl w-full relative flex flex-col ">
        <div className="flex ">
          <div className="w-1/3 h-full p-4">
            <ModalImageCard pokemonData={pokemonData}/>
          </div>
          <div className="w-2/3 p-4">
            <div className="flex justify-between items-center border-b pb-4 mb-4 ">
              <div className='text-2xl font-bold border-r border-SECONDARY pr-5 '>
                {structuredData?.name}
              </div>
              <div className='text-xl font-medium border-r border-SECONDARY pr-5'>
                {id}
              </div>
              <div className="hidden sm:block">
                <ModalControlButtons id={Number(id)} />
              </div>
              <div className='block sm:hidden'>
                <CloseButton />
              </div>
 
            </div>
            <div className="text-gray-700">
              {`${para.slice(0, 450)}`}
              {!showFullDescription && (
                <button
                  className="text-blue-500 hover:text-blue-700"
                  onClick={handleReadMore}
                >
                  ...Read More
                </button>
              )}
 
            </div>
          </div>
          {showFullDescription && (
            <div className="flex bg-blue-900 rounded-md justify-between items-start top-72 absolute ml-4 mr-8">
              <div className='flex w-8/10 p-2'>
                <p className="text-white">{para}</p>
              </div>
              <div className='flex w-2/10 pr-3'>
                <button
                  className="text-white hover:text-gray-300"
                  onClick={handleReadLess}
                >
                  X
                </button>
              </div>
 
            </div>
          )}
        </div>
 
 
        <div className="p-4">
         
          <EvolutionChain id={id} chainUrl={dataSpecies?.evolution_chain.url}/>
        </div>
      </div>
    </div>
  );
}
 
 
export default PokemonPage;