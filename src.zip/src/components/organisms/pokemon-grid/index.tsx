// components/organisms/pokemon-grid/index.tsx
'use client'

import { useState, useEffect } from 'react';
import PokeCard from '@/components/atoms/poke-card';
import Pagination from '@/components/molecules/pagination';
import { useRouter } from 'next/navigation';

interface Pokemon {
  name: string;
  number: number;
  image: string;
}

interface PokemonGridProps {
  searchQuery: string;
  currentPage: number;
}

const ITEMS_PER_PAGE = 20;

const PokemonGrid: React.FC<PokemonGridProps> = ({ searchQuery, currentPage }) => {
  const [pokemon, setPokemon] = useState<Pokemon[]>([]);
  const [filteredPokemon, setFilteredPokemon] = useState<Pokemon[]>([]);
  const [totalPages, setTotalPages] = useState(1);
  const router = useRouter();

  useEffect(() => {
    const fetchPokemon = async () => {
      try {
        const offset = (currentPage - 1) * ITEMS_PER_PAGE;
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=${ITEMS_PER_PAGE}&offset=${offset}`);
        const data = await response.json();
        
        const pokemonDetails = await Promise.all(data.results.map(async (p: any) => {
          const detailResponse = await fetch(p.url);
          const detailData = await detailResponse.json();
          return {
            name: p.name,
            number: detailData.id,
            image: detailData.sprites.other.dream_world.front_default
          };
        }));

        setPokemon(pokemonDetails);
        setFilteredPokemon(pokemonDetails);
        setTotalPages(Math.ceil(data.count / ITEMS_PER_PAGE));
      } catch (error) {
        console.error('Error fetching Pokemon:', error);
      }
    };

    fetchPokemon();
  }, [currentPage]);

  useEffect(() => {
    const filtered = pokemon.filter(p => {
      const paddedNumber = p.number.toString().padStart(3, '0');
      return p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
             paddedNumber.includes(searchQuery);
    });
    setFilteredPokemon(filtered);
  }, [searchQuery, pokemon]);

  const handleCardClick = (number: number) => {
    router.push(`/pokemon/${number}`);
  };

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4 p-4">
        {filteredPokemon.map((p) => (
          <PokeCard
            key={p.number}
            imageSrc={p.image}
            name={p.name}
            number={p.number}
            onClick={() => handleCardClick(p.number)}
          />
        ))}
      </div>
      <Pagination currentPage={currentPage} totalPages={totalPages} />
    </>
  );
};

export default PokemonGrid;