import React from 'react';
import Dropdown from '@/components/atoms/dropdown';

const TypeDD = () => {
  const options = ['Normal', 'Fighting', 'Flying', 'Poison', 'Ground', 'Rock'];

  return (
    <div className='hidden md:flex'>
      <Dropdown label="Type" options={options} />
    </div>
  );
};

export default TypeDD;