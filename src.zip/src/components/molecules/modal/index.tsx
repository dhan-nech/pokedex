import React from 'react';
import Image from 'next/image';
import { FaTimes, FaArrowLeft, FaArrowRight } from 'react-icons/fa';

interface ModalProps {
  card: {
    imageSrc: string;
    name: string;
    number?: number;
  };
  onClose: () => void;
  onPrevCard: () => void;
  onNextCard: () => void;
}

const Modal: React.FC<ModalProps> = ({ card, onClose, onPrevCard, onNextCard }) => {
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg relative">
        <div className="absolute top-2 right-2 flex">
          <button
            className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 transition-colors duration-200 mr-2"
            onClick={onPrevCard}
          >
            <FaArrowLeft className="text-gray-600" />
          </button>
          <button
            className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 transition-colors duration-200 mr-2"
            onClick={onNextCard}
          >
            <FaArrowRight className="text-gray-600" />
          </button>
          <button
            className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 transition-colors duration-200"
            onClick={onClose}
          >
            <FaTimes className="text-gray-600" />
          </button>
        </div>
        <div className="p-8">
          <div className="h-[100px] w-[100px] mb-4 mx-auto">
            <Image src={card.imageSrc} alt={card.name} className="mx-auto" height={100} width={100} />
          </div>
          <h2 className="text-xl font-bold mb-2 text-center">{card.name}</h2>
          {card.number && <p className="text-lg font-bold text-center mb-4">{card.number.toString().padStart(3, '0')}</p>}
        </div>
      </div>
    </div>
  );
};

export default Modal;