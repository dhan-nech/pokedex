// components/molecules/search/index.tsx
import React from 'react';
import GeneralInputBox from '@/components/atoms/input-box';
import { FaSearch } from 'react-icons/fa';

interface SearchBoxProps {
  onSearch: (query: string) => void;
  searchQuery: string;
}

const SearchBox: React.FC<SearchBoxProps> = ({ onSearch, searchQuery }) => {
  return (
    <div className="relative">
      <GeneralInputBox 
        label="Search By" 
        placeholder="Name or Number" 
        className="pr-10" 
        value={searchQuery}
        onChange={(e) => onSearch(e.target.value)}
      />
      {/* <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
        <FaSearch className="text-gray-400" />
      </div> */}
    </div>
  );
};

export default SearchBox;